<?php

namespace App\Controllers;

class ProdukController extends BaseController
{
    public function index()
    {
        return view('v_produk');
    }
}
